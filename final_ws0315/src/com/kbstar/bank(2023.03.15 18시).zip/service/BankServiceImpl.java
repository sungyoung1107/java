package com.kbstar.service;

import java.util.List;

import com.kbstar.dao.AccountDaoImpl;
import com.kbstar.dao.TransactionDaoImpl;
import com.kbstar.dao.UserDaoImpl;
import com.kbstar.dto.AccountDTO;
import com.kbstar.dto.TransactionDTO;
import com.kbstar.dto.UserDTO;
import com.kbstar.frame.BankService;
import com.kbstar.frame.DAO;
import com.kbstar.frame.MakeAccountNumber;

public class BankServiceImpl implements BankService<UserDTO, AccountDTO, TransactionDTO, String, String> {
	DAO<String, UserDTO> userDao;
	DAO<String, AccountDTO> accountDao;
	DAO<String, TransactionDTO> transactionDao;

	UserDTO user = null;

	public BankServiceImpl() {
		userDao = new UserDaoImpl();
		accountDao = new AccountDaoImpl();
		transactionDao = new TransactionDaoImpl();

	}

	@Override
	public void register(UserDTO v) throws Exception {
		try {
			userDao.insert(v);
		} catch (Exception e) {
			e.printStackTrace();
//			e.getStackTrace();
			throw new Exception("등록오류");
		}
	}

	@Override
	public UserDTO login(String k, String p) throws Exception {

		user = userDao.select(k);
		if (user != null) {
			if (user.getPw().equals(p)) {
				System.out.println("로그인 OK");
			} else {
				throw new Exception("PWD가 일치하지 않습니다.");
			}
		} else {
			throw new Exception("로그인실패");
		}

		return user;
	}

	@Override
	public UserDTO getUserInfo(String k) throws Exception {
		UserDTO user = null;
		user = userDao.select(k);
		return user;
	}

	@Override
	public void makeAccount(String k, double balance) throws Exception {
	}

	@Override
	public List<AccountDTO> getAllAccount(String k) throws Exception {
		return accountDao.search(k);
	}

	@Override
	public List<TransactionDTO> getAllTr(String accNum) throws Exception {
		return transactionDao.search(accNum);
	}

	@Override
	public void transaction(String sendAcc, double money, String type, String rAcc) throws Exception {
		System.out.println("금융결제원에 정보가 송부되었습니다.");
		// 내 잔액 조회.
		AccountDTO acc = null;
		acc = accountDao.select(sendAcc);
		if (money > acc.getBalance()) {
			throw new Exception("잔액부족");
		}
		double newbalance = acc.getBalance() - money;
		// 수정된 정보 다시 account에 넣어주기
		acc.setBalance(newbalance);
		accountDao.update(acc);

		// 거래 내역 추가
		TransactionDTO tr = new TransactionDTO(sendAcc, money, "O", rAcc);
		transactionDao.insert(tr);
		System.out.println(tr);

		String userid = acc.getAccHolder();
		UserDTO u = userDao.select(userid);
		System.out.println(sendAcc + "에서 " + rAcc + money + "원 이체 완료되었습니다. 잔액은 " + acc.getBalance() + "원입니다.");

		// 구현 못한것.... 계좌번호 입력 시 우리 db에 있는 것인지 여부와 상대계좌의 잔액 증가 구현 못함

	}
}